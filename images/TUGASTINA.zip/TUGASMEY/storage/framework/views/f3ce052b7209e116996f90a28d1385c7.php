

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Daftar Film MEY RISNAWATI</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="/listfilm/create" class="btn btn-primary mb-3">+ Tambah Film</a>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Judul</th>
                <th>Sutradara</th>
                <th>Cover</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($film->judul); ?></td>
                <td><?php echo e($film->sutradara); ?></td>
                <td><img src="<?php echo e(asset('img/'.$film->cover)); ?>" width="80"></td>
                <td>
                    <a href="/listfilm/<?php echo e($film->slug); ?>" class="btn btn-info btn-sm">Lihat</a>
                    <a href="/listfilm/edit/<?php echo e($film->id); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="/listfilm/delete/<?php echo e($film->id); ?>" class="btn btn-danger btn-sm"
                       onclick="return confirm('Hapus data ini?')">Hapus</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MEY\PABWEB\Laravelmey\TUGASMEY\resources\views/listfilm/index.blade.php ENDPATH**/ ?>