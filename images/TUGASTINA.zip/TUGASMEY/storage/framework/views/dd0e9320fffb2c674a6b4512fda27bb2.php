

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            <h3><?php echo e($film->judul); ?></h3>
        </div>
        <div class="card-body">
            <p><strong>Sutradara:</strong> <?php echo e($film->sutradara); ?></p>
            <p><?php echo e($film->synopsis); ?></p>
            <img src="<?php echo e(asset('img/'.$film->cover)); ?>" width="200">
        </div>
        <div class="card-footer">
            <a href="/listfilm" class="btn btn-secondary">Kembali</a>
            <a href="/listfilm/edit/<?php echo e($film->id); ?>" class="btn btn-warning">Edit</a>
            <a href="/listfilm/delete/<?php echo e($film->id); ?>" class="btn btn-danger"
               onclick="return confirm('Yakin hapus film ini?')">Delete</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MEY\PABWEB\Laravelmey\TUGASMEY\resources\views/listfilm/detail.blade.php ENDPATH**/ ?>