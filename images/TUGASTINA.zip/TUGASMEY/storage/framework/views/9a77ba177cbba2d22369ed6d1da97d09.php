

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Tambah Film Baru</h2>
    <form action="/listfilm/store" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group mb-2">
            <label>Judul</label>
            <input type="text" name="judul" class="form-control" value="<?php echo e(old('judul')); ?>">
        </div>
        <div class="form-group mb-2">
            <label>Sutradara</label>
            <input type="text" name="sutradara" class="form-control" value="<?php echo e(old('sutradara')); ?>">
        </div>
        <div class="form-group mb-2">
            <label>Synopsis</label>
            <textarea name="synopsis" class="form-control"><?php echo e(old('synopsis')); ?></textarea>
        </div>
        <div class="form-group mb-3">
            <label>Cover (nama file gambar)</label>
            <input type="text" name="cover" class="form-control" value="<?php echo e(old('cover')); ?>">
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="/listfilm" class="btn btn-secondary">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MEY\PABWEB\Laravelmey\TUGASMEY\resources\views/listfilm/create.blade.php ENDPATH**/ ?>