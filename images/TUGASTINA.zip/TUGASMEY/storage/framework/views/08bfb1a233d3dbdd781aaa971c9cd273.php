

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Edit Film</h2>
    <form action="/listfilm/update/<?php echo e($film->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group mb-2">
            <label>Judul</label>
            <input type="text" name="judul" class="form-control" value="<?php echo e($film->judul); ?>">
        </div>
        <div class="form-group mb-2">
            <label>Sutradara</label>
            <input type="text" name="sutradara" class="form-control" value="<?php echo e($film->sutradara); ?>">
        </div>
        <div class="form-group mb-2">
            <label>Synopsis</label>
            <textarea name="synopsis" class="form-control"><?php echo e($film->synopsis); ?></textarea>
        </div>
        <div class="form-group mb-3">
            <label>Cover</label>
            <input type="text" name="cover" class="form-control" value="<?php echo e($film->cover); ?>">
        </div>
        <button type="submit" class="btn btn-success">Update</button>
        <a href="/listfilm" class="btn btn-secondary">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH MEY\PABWEB\Laravelmey\TUGASMEY\resources\views/listfilm/edit.blade.php ENDPATH**/ ?>