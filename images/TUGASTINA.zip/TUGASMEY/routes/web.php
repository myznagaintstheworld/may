<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});
use App\Http\Controllers\FilmController;

Route::get('/', [FilmController::class, 'index']);
Route::get('/listfilm', [FilmController::class, 'index']);
Route::get('/listfilm/create', [FilmController::class, 'create']);
Route::post('/listfilm/store', [FilmController::class, 'store']);
Route::get('/listfilm/{slug}', [FilmController::class, 'show']);
Route::get('/listfilm/edit/{id}', [FilmController::class, 'edit']);
Route::post('/listfilm/update/{id}', [FilmController::class, 'update']);
Route::get('/listfilm/delete/{id}', [FilmController::class, 'destroy']);
