@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            <h3>{{ $film->judul }}</h3>
        </div>
        <div class="card-body">
            <p><strong>Sutradara:</strong> {{ $film->sutradara }}</p>
            <p>{{ $film->synopsis }}</p>
            <img src="{{ asset('img/'.$film->cover) }}" width="200">
        </div>
        <div class="card-footer">
            <a href="/listfilm" class="btn btn-secondary">Kembali</a>
            <a href="/listfilm/edit/{{ $film->id }}" class="btn btn-warning">Edit</a>
            <a href="/listfilm/delete/{{ $film->id }}" class="btn btn-danger"
               onclick="return confirm('Yakin hapus film ini?')">Delete</a>
        </div>
    </div>
</div>
@endsection
