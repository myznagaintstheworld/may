@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <h2>Daftar Film MEY RISNAWATI</h2>

    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <a href="/listfilm/create" class="btn btn-primary mb-3">+ Tambah Film</a>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Judul</th>
                <th>Sutradara</th>
                <th>Cover</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($films as $film)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $film->judul }}</td>
                <td>{{ $film->sutradara }}</td>
                <td><img src="{{ asset('img/'.$film->cover) }}" width="80"></td>
                <td>
                    <a href="/listfilm/{{ $film->slug }}" class="btn btn-info btn-sm">Lihat</a>
                    <a href="/listfilm/edit/{{ $film->id }}" class="btn btn-warning btn-sm">Edit</a>
                    <a href="/listfilm/delete/{{ $film->id }}" class="btn btn-danger btn-sm"
                       onclick="return confirm('Hapus data ini?')">Hapus</a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
