@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <h2>Edit Film</h2>
    <form action="/listfilm/update/{{ $film->id }}" method="POST">
        @csrf
        <div class="form-group mb-2">
            <label>Judul</label>
            <input type="text" name="judul" class="form-control" value="{{ $film->judul }}">
        </div>
        <div class="form-group mb-2">
            <label>Sutradara</label>
            <input type="text" name="sutradara" class="form-control" value="{{ $film->sutradara }}">
        </div>
        <div class="form-group mb-2">
            <label>Synopsis</label>
            <textarea name="synopsis" class="form-control">{{ $film->synopsis }}</textarea>
        </div>
        <div class="form-group mb-3">
            <label>Cover</label>
            <input type="text" name="cover" class="form-control" value="{{ $film->cover }}">
        </div>
        <button type="submit" class="btn btn-success">Update</button>
        <a href="/listfilm" class="btn btn-secondary">Kembali</a>
    </form>
</div>
@endsection
