@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <h2>Tambah Film Baru</h2>
    <form action="/listfilm/store" method="POST">
        @csrf
        <div class="form-group mb-2">
            <label>Judul</label>
            <input type="text" name="judul" class="form-control" value="{{ old('judul') }}">
        </div>
        <div class="form-group mb-2">
            <label>Sutradara</label>
            <input type="text" name="sutradara" class="form-control" value="{{ old('sutradara') }}">
        </div>
        <div class="form-group mb-2">
            <label>Synopsis</label>
            <textarea name="synopsis" class="form-control">{{ old('synopsis') }}</textarea>
        </div>
        <div class="form-group mb-3">
            <label>Cover (nama file gambar)</label>
            <input type="text" name="cover" class="form-control" value="{{ old('cover') }}">
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="/listfilm" class="btn btn-secondary">Kembali</a>
    </form>
</div>
@endsection
