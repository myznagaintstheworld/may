<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('listfilm', function (Blueprint $table) {
            $table->id();
            $table->string('slug', 255);
            $table->string('judul', 255);
            $table->string('sutradara', 255);
            $table->string('synopsis', 1000);
            $table->string('cover', 255);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('listfilm');
    }
};
