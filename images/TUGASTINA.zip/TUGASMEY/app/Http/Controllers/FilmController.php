<?php

namespace App\Http\Controllers;

use App\Models\Film;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class FilmController extends Controller
{
    public function index()
    {
        $films = Film::all();
        return view('listfilm.index', compact('films'));
    }

    public function create()
    {
        return view('listfilm.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'judul' => 'required|unique:listfilm',
            'sutradara' => 'required',
            'synopsis' => 'required',
            'cover' => 'required'
        ]);

        $validated['slug'] = Str::slug($validated['judul']);
        Film::create($validated);

        return redirect('/listfilm')->with('success', 'Data berhasil ditambahkan!');
    }

    public function show($slug)
    {
        $film = Film::where('slug', $slug)->firstOrFail();
        return view('listfilm.detail', compact('film'));
    }

    public function edit($id)
    {
        $film = Film::findOrFail($id);
        return view('listfilm.edit', compact('film'));
    }

    public function update(Request $request, $id)
    {
        $film = Film::findOrFail($id);
        $film->update($request->all());
        return redirect('/listfilm')->with('success', 'Data berhasil diperbarui!');
    }

    public function destroy($id)
    {
        $film = Film::findOrFail($id);
        $film->delete();
        return redirect('/listfilm')->with('success', 'Data berhasil dihapus!');
    }
}
